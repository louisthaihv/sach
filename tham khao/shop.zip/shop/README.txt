=====================================================
=                                                   =
=                                                   =
=  Plaincart  v 1.1.2                               =
=                                                   =
=                                                   =
=====================================================

_____________________________________________________

Plaincart is free to use, modify or enchance. Just 
remember that it's created as an example for
the shopping cart tutorial in www.phpwebcommerce.com 
so i disclaim anything if you want to use it on a 
live site
_____________________________________________________


INSTALLATION INSTRUCTIONS

1.) Unzip plaincart.zip to the root folder under your 
    HTTP directory ( or under your preferred directory) 


2.) Create a database and database user on your web
    server for Plaincart

3.) Use the sql dump in plaincart.sql to generate the
    tables and example data

4.) Modify the database connection settings in 
    library/config.php.

5.) If you want to accept paypal modify the settings
    in include/paypal/paypal.inc.php . More information
    about this paypal stuff can be found in 
    http://www.phpwebcommerce.com/shop-checkout-process/



You can start playing with the shopping cart by
login to the administrator page. The default 
id and password is 'admin' ( without the quotes )
_____________________________________________________
