<p>&nbsp;</p>
<p><small>&copy; 2010 MyOnlineShop&nbsp;</small></p>
</body>
</html>